"use client";

import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import type { Story } from "@/lib/types";

interface StoryGeneratorProps {
  onStoryCreated: (story: Story) => void;
}

const GENRES = [
  "mystery",
  "thriller",
  "psychological",
  "noir",
  "supernatural",
  "literary",
];

export default function StoryGenerator({ onStoryCreated }: StoryGeneratorProps) {
  const [premise, setPremise] = useState("");
  const [genre, setGenre] = useState("mystery");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/stories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          premise: premise.trim() || undefined,
          genre,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Failed to generate story");
      }

      const story: Story = await res.json();
      onStoryCreated(story);
      setPremise("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="mb-5 flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-accent" />
        <h2 className="font-serif text-xl text-foreground">Craft a new story</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-foreground/50">
            Starting premise (optional)
          </label>
          <textarea
            value={premise}
            onChange={(e) => setPremise(e.target.value)}
            placeholder="Leave empty for a surprise, or write the first sentence..."
            rows={3}
            className="w-full resize-none rounded-xl border border-border bg-muted/40 px-4 py-3 text-sm text-foreground placeholder:text-foreground/30 focus:border-accent/50 focus:outline-none focus:ring-1 focus:ring-accent/30"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-foreground/50">
            Genre
          </label>
          <div className="flex flex-wrap gap-2">
            {GENRES.map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => setGenre(g)}
                className={`rounded-full px-3.5 py-1.5 text-xs font-medium capitalize transition-all ${
                  genre === g
                    ? "bg-accent text-background"
                    : "bg-muted/60 text-foreground/70 hover:bg-muted hover:text-foreground"
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <p className="text-sm text-red-400">{error}</p>
        )}

        <button
          onClick={handleGenerate}
          disabled={loading}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-accent py-3.5 text-sm font-semibold text-background transition-all hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Weaving the secret...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4" />
              Generate story
            </>
          )}
        </button>
      </div>
    </div>
  );
}
