"use client";

import { BookOpen } from "lucide-react";

export default function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent/10">
            <BookOpen className="h-5 w-5 text-accent" />
          </div>
          <span className="font-serif text-xl tracking-wide text-foreground">
            Twist<span className="text-accent">AI</span>
          </span>
        </div>
        <p className="hidden text-sm text-foreground/60 sm:block">
          Every story has a secret.
        </p>
      </div>
    </header>
  );
}
