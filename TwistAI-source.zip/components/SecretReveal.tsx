"use client";

import { Lock } from "lucide-react";

interface SecretRevealProps {
  secret: string;
}

export default function SecretReveal({ secret }: SecretRevealProps) {
  return (
    <div className="animate-fade-in rounded-xl border border-accent/30 bg-accent/5 p-5">
      <div className="mb-2 flex items-center gap-2 text-accent">
        <Lock className="h-4 w-4" />
        <span className="text-xs font-semibold uppercase tracking-widest">
          The Secret
        </span>
      </div>
      <p className="font-serif text-base leading-relaxed text-foreground">
        {secret}
      </p>
    </div>
  );
}
