"use client";

import { useState } from "react";
import { Eye, EyeOff, Clock } from "lucide-react";
import type { Story } from "@/lib/types";
import SecretReveal from "./SecretReveal";

interface StoryCardProps {
  story: Story;
  onReveal?: (id: string) => void;
}

export default function StoryCard({ story, onReveal }: StoryCardProps) {
  const [revealed, setRevealed] = useState(story.isRevealed);

  const handleReveal = () => {
    setRevealed(true);
    onReveal?.(story.id);
  };

  return (
    <article className="group animate-slide-up rounded-2xl border border-border bg-card p-6 transition-all hover:border-accent/30 hover:shadow-lg hover:shadow-accent/5">
      <div className="mb-4 flex items-start justify-between gap-4">
        <div>
          <span className="mb-2 inline-block rounded-full bg-accent/10 px-3 py-0.5 text-xs font-medium uppercase tracking-wider text-accent">
            {story.genre}
          </span>
          <h3 className="font-serif text-2xl text-foreground">{story.title}</h3>
        </div>
        <div className="flex items-center gap-1 text-xs text-foreground/40">
          <Clock className="h-3.5 w-3.5" />
          <span>
            {new Date(story.createdAt).toLocaleDateString(undefined, {
              month: "short",
              day: "numeric",
            })}
          </span>
        </div>
      </div>

      <p className="mb-4 text-sm leading-relaxed text-foreground/70">
        {story.premise}
      </p>

      <div className="mb-6 whitespace-pre-line text-sm leading-relaxed text-foreground/90">
        {story.content}
      </div>

      {revealed ? (
        <SecretReveal secret={story.secret} />
      ) : (
        <button
          onClick={handleReveal}
          className="flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-muted/50 py-3 text-sm font-medium text-foreground/80 transition-all hover:border-accent/40 hover:bg-accent/5 hover:text-accent"
        >
          <Eye className="h-4 w-4" />
          Reveal the secret
        </button>
      )}
    </article>
  );
}
