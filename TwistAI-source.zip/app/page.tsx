"use client";

import { useEffect, useState } from "react";
import StoryGenerator from "@/components/StoryGenerator";
import StoryCard from "@/components/StoryCard";
import type { Story } from "@/lib/types";

export default function HomePage() {
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/stories")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setStories(data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleStoryCreated = (story: Story) => {
    setStories((prev) => [story, ...prev]);
  };

  const handleReveal = async (id: string) => {
    try {
      await fetch(`/api/stories?id=${id}`, {
        method: "PATCH",
      });
      setStories((prev) =>
        prev.map((s) => (s.id === id ? { ...s, isRevealed: true } : s))
      );
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      {/* Hero */}
      <section className="mb-16 text-center">
        <h1 className="mb-4 font-serif text-5xl tracking-tight text-foreground sm:text-6xl">
          Twist<span className="text-accent">AI</span>
        </h1>
        <p className="mx-auto max-w-xl text-lg text-foreground/60">
          Every story has a secret.
          <br />
          <span className="text-sm">
            Generate atmospheric tales with hidden twists waiting to be revealed.
          </span>
        </p>
      </section>

      {/* Generator */}
      <section className="mb-16">
        <StoryGenerator onStoryCreated={handleStoryCreated} />
      </section>

      {/* Stories */}
      <section>
        <h2 className="mb-6 font-serif text-2xl text-foreground">
          Your stories
        </h2>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-accent border-t-transparent" />
          </div>
        ) : stories.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border py-16 text-center">
            <p className="text-foreground/50">
              No stories yet. Generate your first one above.
            </p>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-1">
            {stories.map((story) => (
              <StoryCard
                key={story.id}
                story={story}
                onReveal={handleReveal}
              />
            ))}
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="mt-24 border-t border-border pt-8 text-center text-xs text-foreground/40">
        <p>TwistAI — Every story has a secret.</p>
        <p className="mt-1">Built for local development. No API key required.</p>
      </footer>
    </div>
  );
}
