import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";

export const metadata: Metadata = {
  title: "TwistAI — Every story has a secret.",
  description:
    "AI-powered storytelling where every narrative hides a secret waiting to be revealed.",
  openGraph: {
    title: "TwistAI",
    description: "Every story has a secret.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <Header />
        <main className="pt-16">{children}</main>
      </body>
    </html>
  );
}
