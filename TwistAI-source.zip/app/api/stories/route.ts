import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateStory } from "@/lib/ai";

export async function GET() {
  try {
    const stories = await prisma.story.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(stories);
  } catch (error) {
    console.error("GET /api/stories error:", error);
    // Return empty array if DB not ready yet
    return NextResponse.json([]);
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { premise, genre } = body;

    const generated = await generateStory({ premise, genre });

    const story = await prisma.story.create({
      data: {
        title: generated.title,
        premise: generated.premise,
        content: generated.content,
        secret: generated.secret,
        genre: generated.genre,
        isRevealed: false,
      },
    });

    return NextResponse.json(story, { status: 201 });
  } catch (error) {
    console.error("POST /api/stories error:", error);
    return NextResponse.json(
      { error: "Failed to create story. Make sure you ran `npx prisma db push`." },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Missing id" }, { status: 400 });
    }

    const story = await prisma.story.update({
      where: { id },
      data: { isRevealed: true },
    });

    return NextResponse.json(story);
  } catch (error) {
    console.error("PATCH /api/stories error:", error);
    return NextResponse.json({ error: "Failed to update story" }, { status: 500 });
  }
}
