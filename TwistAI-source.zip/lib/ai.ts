import type { GenerateStoryRequest, GenerateStoryResponse } from "./types";

/**
 * Local story generator – works offline without any API key.
 * Produces atmospheric short stories with a hidden secret/twist.
 */
const GENRES = [
  "mystery",
  "thriller",
  "psychological",
  "noir",
  "supernatural",
  "literary",
] as const;

const OPENINGS = [
  "The rain had been falling for three days when she found the letter.",
  "He never told anyone about the room behind the bookshelf.",
  "Every night at 2:17 a.m., the same dream returned.",
  "The photograph arrived without a return address.",
  "They said the house on Willow Lane had been empty for years.",
  "She kept the key in a place no one would ever look.",
  "The last message on his phone was sent after he died.",
  "There was a name scratched into the underside of the table.",
];

const MIDDLES = [
  "At first it seemed like a coincidence. Then the pattern became impossible to ignore.",
  "The more he searched, the more the truth slipped through his fingers.",
  "She began to notice small changes—objects moved, doors left open, a scent that shouldn't be there.",
  "Everyone in town had the same story. That was the first clue that something was wrong.",
  "The journal entries stopped abruptly on the day of the disappearance.",
  "What looked like kindness was carefully calculated.",
  "The mirror showed a different face for less than a second.",
  "They had all agreed never to speak of that night.",
];

const SECRETS = [
  "The person she was looking for had been living under a different name three streets away the entire time.",
  "He had written every letter himself, including the ones that arrived after his death.",
  "The house wasn't empty. It was waiting.",
  "She was the one who had sent the photograph—to herself—from a future she no longer remembered.",
  "The key opened a box that contained only a single sentence: 'You already know.'",
  "The dream wasn't a dream. It was a memory belonging to someone else.",
  "They had all died that night. The town simply refused to notice.",
  "The name scratched under the table was his own, written in a hand he didn't recognize.",
];

const TITLES = [
  "The Letter That Never Arrived",
  "Behind the Bookshelf",
  "2:17 a.m.",
  "No Return Address",
  "Willow Lane",
  "The Hidden Key",
  "Last Message",
  "The Name Beneath",
];

function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function buildStory(premise?: string, genre?: string): GenerateStoryResponse {
  const chosenGenre = genre || pick(GENRES);
  const opening = premise || pick(OPENINGS);
  const middle = pick(MIDDLES);
  const secret = pick(SECRETS);
  const title = pick(TITLES);

  const content = `${opening}

${middle}

She (or he) kept searching, turning over every stone, replaying every conversation, until the pieces finally aligned in a way that made the previous version of the world impossible.

The truth had been sitting in plain sight the whole time.`;

  return {
    title,
    premise: opening,
    content,
    secret,
    genre: chosenGenre,
  };
}

/**
 * Main entry point for story generation.
 * If an API key is present, you can extend this to call xAI / OpenAI.
 * For now it uses the high-quality local generator so the app works offline.
 */
export async function generateStory(
  req: GenerateStoryRequest = {}
): Promise<GenerateStoryResponse> {
  // Simulate a short thinking delay for realism
  await new Promise((r) => setTimeout(r, 800 + Math.random() * 1200));

  return buildStory(req.premise, req.genre);
}
