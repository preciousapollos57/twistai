export interface Story {
  id: string;
  title: string;
  premise: string;
  content: string;
  secret: string;
  genre: string;
  isRevealed: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface GenerateStoryRequest {
  premise?: string;
  genre?: string;
  length?: "short" | "medium" | "long";
}

export interface GenerateStoryResponse {
  title: string;
  premise: string;
  content: string;
  secret: string;
  genre: string;
}
