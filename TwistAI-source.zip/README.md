# TwistAI

**Every story has a secret.**

An atmospheric AI storytelling app that generates short literary tales with a hidden twist.  
You can reveal the secret only after reading the story.

Built with **Next.js 14**, **TypeScript**, **Tailwind CSS**, and **Prisma** (SQLite).

---

## Features

- Generate original short stories with a built-in local story engine (no API key required)
- Choose a genre or provide your own premise
- Each story hides a secret that can be revealed later
- Stories are persisted in a local SQLite database
- Dark, cinematic UI matching the “Every story has a secret” aesthetic

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Create the database
npx prisma db push

# 3. Start the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

---

## Project Structure

```
TwistAI-source/
├── app/
│   ├── api/stories/route.ts   # REST API for stories
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx               # Main UI
├── components/
│   ├── Header.tsx
│   ├── StoryGenerator.tsx
│   ├── StoryCard.tsx
│   └── SecretReveal.tsx
├── lib/
│   ├── ai.ts                  # Local story generator
│   ├── prisma.ts
│   └── types.ts
├── prisma/
│   └── schema.prisma
├── public/
├── .env.example
├── package.json
└── README.md
```

---

## Optional: Real AI Generation

The app ships with a high-quality offline story generator so it works immediately.

If you want to plug in a real model (xAI Grok, OpenAI, etc.):

1. Copy `.env.example` → `.env`
2. Add your API key
3. Extend `lib/ai.ts` to call the provider when a key is present

---

## Scripts

| Command              | Description                     |
|----------------------|---------------------------------|
| `npm run dev`        | Start development server        |
| `npm run build`      | Production build                |
| `npm run start`      | Start production server         |
| `npx prisma db push` | Sync database schema            |
| `npx prisma studio`  | Open database GUI               |

---

## License

MIT — feel free to use, modify, and share.
